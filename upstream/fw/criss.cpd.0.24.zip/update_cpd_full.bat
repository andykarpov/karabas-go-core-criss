R1715upl.exe %1 4=cpd_start_screen.bin 3=cpd.hex.bin A=4:* A=3:*
