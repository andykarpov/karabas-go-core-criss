R1715upl.exe 15 0=cpu.hex.bin 1=cpu.hex.bin A=0:00-ff A=1:*
