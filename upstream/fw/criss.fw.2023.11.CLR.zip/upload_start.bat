R1715upl.exe %1 0=cpu.hex.bin 1=cpu.hex.bin 3=cpd.hex.bin 4=cpd_start_screen.bin 5=vga_328.hex.bin 6=vga_328.eep.bin A=0:00-ff A=1:* A=3:* A=4:* A=5:00-0f A=6:*
