R1715upl.exe %1 7=clr.hex.bin 8=clr_eeprom.bin A=7:08-38 A=8:00-07

